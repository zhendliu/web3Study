// +build !darwin

package opt

var (
	DefaultOpenFilesCacheCapacity = 500
)
