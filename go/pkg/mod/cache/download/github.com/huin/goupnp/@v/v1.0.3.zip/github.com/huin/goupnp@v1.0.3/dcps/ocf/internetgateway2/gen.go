//go:generate goupnpdcpgen -dcp_name ocf/internetgateway2
package internetgateway2
